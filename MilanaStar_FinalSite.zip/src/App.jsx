// Магазин MERCH Milana Star на React + Tailwind
import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";

const socialLinks = [
  {
    name: "Instagram",
    url: "https://www.instagram.com/milana__star",
  },
  {
    name: "Telegram",
    url: "https://t.me/milana_offi",
  },
  {
    name: "Wildberries",
    url: "https://www.wildberries.ru/seller/4279898",
  },
];

const products = [
  {
    id: 1,
    title: "Футболка MILANA STAR",
    price: 3485,
    image: "/images/tshirt.jpg",
    description: "Оверсайз футболка с принтом Миланы",
    link: "https://www.wildberries.ru/catalog/201349300/detail.aspx",
    comments: [
      "Очень крутая футболка, дочка в восторге!",
      "Размер подошёл, качество классное!",
      "Ребёнок рад, доставка быстрая."
    ]
  },
  {
    id: 2,
    title: "Картхолдер MILANA STAR",
    price: 988,
    image: "/images/cardholder.jpg",
    description: "Универсальный держатель с фото Миланы",
    link: "https://www.wildberries.ru/catalog/207896107/detail.aspx",
    comments: [
      "Очень милый картхолдер! Качество на высоте!",
      "Подарила племяннице, она в восторге.",
      "Красивый, стильный и удобный!"
    ]
  },
  {
    id: 3,
    title: "Ручка MILANA STAR",
    price: 461,
    image: "/images/pen.jpg",
    description: "Розовая ручка с логотипом Milana Star",
    link: "https://www.wildberries.ru/catalog/207896118/detail.aspx",
    comments: [
      "Пишет хорошо, дочка носит в школу!",
      "Очень красивая, как на фото.",
      "Ребёнок доволен, качество отличное."
    ]
  },
];

function App() {
  return (
    <div className="p-4 bg-pink-50 min-h-screen">
      <h1 className="text-3xl font-bold text-center text-pink-600 mb-6">
        Официальный магазин Milana Star
      </h1>

      <div className="flex justify-center gap-4 mb-6">
        {socialLinks.map((link) => (
          <a
            key={link.name}
            href={link.url}
            target="_blank"
            className="text-pink-700 hover:text-pink-900 underline text-sm"
          >
            {link.name}
          </a>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {products.map((product) => (
          <div key={product.id} className="bg-white shadow-xl rounded-2xl overflow-hidden">
            <img
              src={product.image}
              alt={product.title}
              className="w-full h-64 object-cover"
            />
            <div className="p-4">
              <h2 className="text-xl font-semibold text-pink-700">
                {product.title}
              </h2>
              <p className="text-sm text-gray-500 mb-2">{product.description}</p>
              <p className="font-bold text-lg mb-3">{product.price}₽</p>
              <a
                href={product.link}
                target="_blank"
                className="block mb-2 text-center text-pink-600 underline"
              >
                Перейти на Wildberries
              </a>
              <button className="bg-pink-600 hover:bg-pink-700 w-full text-white py-2 rounded">
                В корзину
              </button>
              <div className="mt-4">
                <h3 className="font-bold text-sm mb-1">Отзывы:</h3>
                <ul className="text-sm text-gray-600 list-disc ml-4">
                  {product.comments.map((comment, index) => (
                    <li key={index}>{comment}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

export default App;
